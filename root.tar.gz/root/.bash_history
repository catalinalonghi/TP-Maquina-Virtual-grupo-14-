apt-get install openssh-server
apt update
apt install openssh-server -y
vim /etc/apt/sources.list
apt update
apt-get install openssh-server
systemcl status ssh
systemctl status ssh
apt-cache show openssh-server
systemctl status ssh
vim /etc/ssh/sshd_config
systemctl restat ssh
systemctl restart ssh
mkdir -p /root/.ssh
clear
poweroff
hostname -i
hostname -I
ip a
systemclt status ssh
systemctl status ssh
poweroff
systemctl status ssh
ip a
poweroff
ss 'tlnp | grep ":22"
ss -tlnp | grep ":22"
vim /etc/ssh
vim /etc/sshd_config
vim /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
vim /etc/ssh/sshd_config
systemctl restart ssh
ls 'la
pwd
cd ..
cd tmp
ls
cat /tmp/clave_publica.p >> /root/.ssh/authorized_keys 
cat /tmp/clave_publica.p >> /root/.ssh/authorized_keys 
cat /tmp/clave_publica.pub >> /root/.ssh/authorized_keys 
ls 'l
ls -l
chmod 600 /root/.ssh/authorized_keys 
ls -l
ls -l /tmp/clave_publica.pub 
vim /etc/ssh/sshd_config
clear
cd..
cd ..
cd ..
apache2 -v
apt update
apt install apache2 
systemctl status apache2
poweroff
systemctl status apache2
cat /etc/debian_version 
ls -la
cd .ssh
ls
cat authorized_keys 
cd ..
ip a
clear
apt install apache2 
systemctl status apache2
apt update
apt install php
php -v
systemctl enable apache2
system status apache2
systemctl status apache2
ip a
http://10.0.2.15
systemctl status apache2
ip a
curl http://localhost
hostname -I
poweroff
ip a
systemctl status apache2
systemctl status ssh
hostname 'I
hostname -I
powroff}
powroff
poweroff
cat /etc/debian_version 
apt update
apt upgrade
apt autoremove
cat /etc/debian_version 
vi /etc/apt/sources.list
apt update
cat /etc/debian_version 
apt full-upgrade
[A
poweroffc
cat debian
reboot
dir "$HOME\Downloads"
exit
ls -l /tmp/web
exit
cat /etc/debian_version 
vi /etc/apt/sources.list
apt full-upgrade
cat /etc/debian_version 
systemctl ssh status
systemctl status ssh
ip a
system enable apache2
systemctl enable apache2
ip a
ip a
systemctl enable apache2
systemctl status apache2
systemctl status php
apt install apache2 php libapache2-mod-php
mkdir /tmp/web
ls 
ls -l
ls /tmp/web/
ls /tmp/web
ip a
systemctl status ssh
hostname -I
hostname
ls -la
cd .ssh
ls
cat authorized_keys 
cs ..
cd ..
ssh-keygen -R 192.168.0.50
cp /tmp/web/index.php /var/www/html/
cp /tmp/web/logo.png /var/www/html/
ls -l /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.bak
systemctl restart apache2
ls -l /var/www
ls -l /var/www/html/
apache2ctl -M | grep php
php -v
apache2ctl -M
ls -l /var/www/html/
curl http://localhost
curl http://localhost
curl http://localhost
cat /var/www/html/index.php 
curl -i http://localhost
cat /var/www/html/index.php 
cat /var/www/html/index.php 
ls -l /var/www/html/
cat /var/www/html/index.php 
php -l /var/www//html/index.php 
curl -s http://localhost/index.php
head -n 20 /var/www/html/index.php 
php /var/www/html/index.php 
apt install php-mysql
systemctl restart apache2
php -m | grep mysqli
apt install mariadb-server
systemctl status mariadb
ls -l /tmp/web/db.sql
head -30 /tmp/web/db.sql 
mariadb < /tmp/web/db.sql
mariadb -e "SHOW DATABASES;"
mariadb -e "USE ingenieria; SHOW TABLES;"
curl http://localhost/index.php
clear
poweroff
systemctl status ssh
vim /etc/ssh/sshd_config
clear
ip a
vim /etc/ssh/sshd_config
ls -l
ls -la
cd /
ls -l
cd root
cd /tmp
ls 
cd root
cd ..
cd ..
ls -la{
ls -la
cd /.ssh
cd .ssh
cd ..
cd root
ls -la
cd /.ssh
cd shh
cat .ssh
poweroff
lsblk
poweroff
fidisk
fdisk
lsblk
fdisk /dev/sdc
fdisk -l
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mount /dev/sdc1 /www_dir
mkdir -p /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp -a /var/www/html/index.php /var/www/html/logo.png /www_dir/
ls -l /ww
ls -l /www_dir
vim /etc/apache2/sites-available/000-default.conf 
apache2ctl configtest 
systemctl reload apache2
journalctl -ex
cat /etc/network/interfaces
vim /etc/apache2/sites-available/000-default.conf 
ls -a
ls -la
ls -l
pwd
cd ..
ls 
ls -la
chmod 755 /www_dir
ls -la
chmod 777 /www_dir
systemctl reload apache2
apache2ctl configtest 
systemctl reload apache2
apache2ctl configtest 
systemctl reload apache2
curl hhtp://localhost
curl http://localhost
systemctl status apache2
curl -I http://localhost
ls -ld /www_dir/
ls -l /www_dir/
cat /etc/apache2/apache2.conf 
cat /etc/apache2/apache2.conf 
vim /etc/apache2/apache2.conf
chown -R www-data:www-data  /www_dir}
chown -R www-data:www-data  /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php  /www_dir/logo.png 
vim /etc/apache2/apache2.conf
apache2 configtest
apache2ctl configtest
systemctl reload apache2
curl -I httpp://localhost
curl -I http://localhost
hostname -I
ip addr
poweoff
poweroff
ip addr
vim /etc/fstab
ls -l
cd /
ls 'l
ls -l
ls -l www_dir
apt update 
dpkg -l php-mysql
apt list --upgradable
mysql --version
cd root
vim /etc/apt/sources.list
apt update
apt upgrade
vim /etc/apt/sources.list
apt update
vim /etc/apt/sources.list
apt update
apt upgrade
vim /etc/apache2/sites-available/000-default.conf 
vim /etc/apache2/apache2.conf 
ip a
systemctl restart networking
systemctl restart networking
poweroff
exit
grep -R "DocumentRoot\|ServerName" /etc/apache2/sites-enabled /etc/httpd/conf.d 2>/dev/null
find /www_dir -maxdepth 2 -type f
curl -I http://localhost
ls -la /www_dir
ls -l /www_dir
cd /
ls -l
ls -l /www_dir/
ls -l /www_dir
ls -la /www_dir
cd ..
cd root
ls -la /var/www
find / -name "index.php" -o -name "logo.png" 2>/dev/null
cp /var/www/html/index.php /var/www/html/logo.png /www_dir/
ls -la /var/www
ls -la /www_dir
curl -i http://localhost/ | head -30
lsblk
mount /dev/sdc1 /www_dir
lsblk -f
exit
exit 
ip a
set -e
cp /etc/fstab "/etc/fstab.bak-before-backup-$(date +%F-%H%M%S)"
if ! grep -qE '^[^#]*[[:space:]]/backup_dir([[:space:]]|$)' /etc/fstab; then   printf '%s\n' 'UUID=82724f7f-9699-4592-a777-d04f229205ed /backup_dir ext4 defaults 0 2' >> /etc/fstab; fi
grep -n backup_dir /etc/fstab
systemctl daemon-reload
mount -a
findmnt /backup_dir
cp /etc/fstab /etc/fstab.bak
grep -qE '^[^#]*[[:space:]]/www_dir[[:space:]]' /etc/fstab || echo 'UUID=4499dbce-1e27-4567-9de8-276af57aacd3 /www_dir ext4 defaults 0 2' >> /etc/fstab
mount -a
findmnt /www_dir
findmint
findmnt
mount -a
lsblk -f
mkdir -p /backup_dir
cp /etc/fstab /etc/fstab.bak-before-backup
grep -qE '^[^#]*[[:space:]]/backup_dir[[:space:]]' /etc/fstab || echo 'UUID=82724f7f-9699-4592-a777-d04f229205ed /backup_dir ext4 defaults 0 2' >> /etc/fstab
mount -a
findmnt /backup_dir
grep /backup_dir /etc/fstab
grep -n backup_dir /etc/fstab
grep -n backup_dir /etc/fstab
findmnt /backup_dir
lsblk -o NAME,SIZE,TYPE,FSTYPE,UUID,MOUNTPOINTS /dev/sdc
fdisk -l /dev/sdc
ls -l /www_dir/index.php /www_dir/logo.png
grep -RniE 'DocumentRoot|<Directory' /etc/apache2/sites-available/000-default.conf /etc/apache2/apache2.conf
apache2ctl configtest
grep -nE '/www_dir|/backup_dir' /etc/fstab
findmnt /www_dir /backup_dir
cat /proc/partitions > /proc/particion
ip route
ls -la /etc/network
cat /etc/network/interfaces
vim /etc/network/interfaces
ip -4 addr show enp0s3
ip route
exit
exit
pwd
ls -la
cd .ssh
cat 
cat .ssh
cat /.ssh
ls -l 
ls -la
cat authorized_keys 
cd ..
ls -la
cd /.ssh
cd .ssh
ls -l
cat authorized_keys 
exit
exit
exit
exit
vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
sshd -t
systemctl restart ssh
head -n 30 /tmp/web/db.sql
find /tmp /var/www /root -type f -name "db.sql" 2>/dev/null
ip addr
ip a
ip route
ip -4 addr
systemctl status ssh
systemctl status sshd
ss -lntp | grep ssh
systemctl status apache2
systemctl status mariadb
curl -I http://localhost
mariadb-admin ping
mariadb
ip a
ls -l /etc/apache2/sites-available/
ls -l /etc/apache2/sites-enabled/
ls -l
ls -l
cd /
ls 'l


ls -l
ls -l /www_dir
ls -la /www_dir/
ls -la /www_dir/
ls -l /www_dir/
ls -l /www_dir/
ls -la /var/www/
ls -la /www_dir/
lsblk -f
cd root
vim /etc/fstab
findmnt /backup_dir 
vim /etc/fstab
grep /backup_dir/ /etc/fstab
vim /etc/fstab
grep -n backup_dir /etc/fstab
ls -l
ls 
cd /
ls 
ls 'l
ls -l
cd /backup_dir/
ls 
cd root
cd ..
cd rppt
cd root
vim /etc/fstab
ls -l /proc/
ls -l /proc
cd /proc/
cat partitions
touch particion
pwd
cat /proc/partitions > /proc/particion
cd ..
cd root
ip a
vim /etc/network/interfaces
vim /etc/network/interfaces
ip route
ip a
systemctl restart networking
ls -l
cd root
cd /
ls -l
ls -la
cd ..
cd root
ls -l
ls -la
cat /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
ls -l /tmp/web/db.sql
mariadb -e
mariadb -e "SHOW DATABASES"
ip -4 addr
ip route
ip -4 addr show enp0s3
ip route
vim /etc/network/interfaces
poweroff
exit
mkdir -p /opt/scripts
touch /opt/scripts/backup_full.sh
chmod 750 /opt/scripts/backup_full.sh
mountpoint /backup_dir
/opt/scripts/backup_full.sh -help
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
vim /opt/scripts/backup_full.sh
chmod 750 /opt/scripts/backup_full.sh
ls -l /opt/scripts/backup_full.sh
cat /opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh -help
ls -ld /var/logs
crontab -e
crontab -l
ls -ld /opt/scripts/backup_full.sh /var/logs /www_dir /backup_dir
ls -ld /var/log
crontab -e
crontab -l
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
mountpoint /backup_dir
ls -l /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
ls -ld /var/log /www_dir /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
Paso 6: probar el backup de /www_dir. Ejecutá:
/opt/scripts/backup_full.sh /www_dir /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
crontab -l
systemctl is-active cron
vim /opt/scripts/backup_full.sh
