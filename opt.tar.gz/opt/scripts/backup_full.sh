#!/bin/bash

# Muestra cómo usar el script.
uso() {
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo "Ayuda: $0 -help"
}

# Opción de ayuda.
if [ "$1" = "-help" ]; then
    uso
    exit 0
fi

# Verifica que se reciban dos argumentos.
if [ "$#" -ne 2 ]; then
    uso
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"

# Comprueba que el origen y el destino existan.
if [ ! -d "$ORIGEN" ]; then
    echo "Error: no existe el directorio de origen: $ORIGEN"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: no existe el directorio de destino: $DESTINO"
    exit 1
fi

# Comprueba que los sistemas de archivos estén disponibles.
if ! findmnt -T "$ORIGEN" >/dev/null 2>&1; then
    echo "Error: el sistema de archivos del origen no está disponible."
    exit 1
fi

if ! findmnt -T "$DESTINO" >/dev/null 2>&1; then
    echo "Error: el sistema de archivos del destino no está disponible."
    exit 1
fi

# Comprueba que /backup_dir esté montado.
if ! mountpoint -q /backup_dir; then
    echo "Error: /backup_dir no está montado."
    exit 1
fi

# Comprueba que el destino esté dentro de /backup_dir.
case "$DESTINO" in
    /backup_dir|/backup_dir/*)
        ;;
    *)
        echo "Error: el destino debe estar dentro de /backup_dir."
        exit 1
        ;;
esac

# Crea el nombre del backup con la fecha YYYYMMDD.
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crea el archivo comprimido.
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Backup creado: $ARCHIVO"
else
    echo "Error al crear el backup."
    exit 1
fi
